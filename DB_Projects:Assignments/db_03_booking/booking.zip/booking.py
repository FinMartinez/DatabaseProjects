"""
CS3810: Principles of Database Systems
Instructor: Thyago Mota
Student(s): Fin Martinez
Description: A room reservation system
"""

import psycopg2
from psycopg2 import extensions, errors
import configparser as cp
from datetime import datetime

def menu(): 
    print('1. List')
    print('2. Reserve')
    print('3. Delete')
    print('4. Quit')

def db_connect():
    config = cp.RawConfigParser()
    config.read('ConfigFile.properties')
    params = dict(config.items('db'))
    conn = psycopg2.connect(**params)
    conn.autocommit = False 
    conn.isolation_level = extensions.ISOLATION_LEVEL_SERIALIZABLE
    with conn.cursor() as cur: 
        cur.execute('''
            PREPARE QueryReservationExists AS 
                SELECT * FROM Reservations 
                WHERE abbr = $1 AND room = $2 AND date = $3 AND period = $4;
        ''')
        cur.execute('''
            PREPARE QueryReservationExistsByCode AS 
                SELECT * FROM Reservations 
                WHERE code = $1;
        ''')
        cur.execute('''
            PREPARE NewReservation AS 
                INSERT INTO Reservations (abbr, room, date, period) VALUES
                ($1, $2, $3, $4);
        ''')
        cur.execute('''
            PREPARE UpdateReservationUser AS 
                UPDATE Reservations SET "user" = $1
                WHERE abbr = $2 AND room = $3 AND date = $4 AND period = $5; 
        ''')
        cur.execute('''
            PREPARE DeleteReservation AS 
                DELETE FROM Reservations WHERE code = $1;
        ''')
        cur.execute('''
            PREPARE setUSer AS
                INSERT INTO Users(name)
                VALUES($1);
        ''')
        cur.execute('''
            PREPARE getID AS 
                SELECT "user" FROM Users
                WHERE name = $1;
        ''')
        cur.execute('''
            PREPARE getCode AS
            SELECT code FROM Reservations
            WHERE abbr = $1 AND room = $2 AND date = $3 AND period = $4; 
        ''')
    return conn

# TODO: display all reservations in the system using the information from ReservationsView
def list_op(conn):
    if conn:
        print('Retrieving Reservations...') 
        cursor = conn.cursor()

        sql = '''SELECT code, TO_CHAR(date, 'YYYY-MM-dd'), period, TO_CHAR(start, 'HH:MI:SS'),
                 TO_CHAR("end", 'HH:MI:SS'), room, name FROM ReservationsView;'''

        cursor.execute(sql)
        
        results = cursor.fetchall()
        print("code " + "date      " + " period  " + "start    " + "   end      " + "building-room " + "user")
        for row in results:
            print('    '.join(str(x) for x in row))
        print("Returning to main menu... \n")
        conn.commit()


# TODO: reserve a room on a specific date and period, also saving the user who's the reservation is for
def reserve_op(conn): 
    conn.set_isolation_level(extensions.ISOLATION_LEVEL_SERIALIZABLE)
    if conn:
        print('Please provide desired reservation date (YYYY-MM-dd).')
        reservation_date = input('Reservation Date: ')
        print('Please select a period of the time (A-H). ')
        period = input('Period: ')
        print('Please provide the building abbreviation and room number.')
        bldg = input('Building: ')
        room = int(input('Room: '))

        print('Searching...\n')

        with conn.cursor() as cur:

            cur.execute("execute QueryReservationExists(%s, %s, %s, %s)", (bldg, room, reservation_date, period))
            if cur.fetchone() is not None:
                print('Reservation not secured.\nReturning to main menu...')
                conn.rollback()
            else:
                cur.execute("execute NewReservation(%s, %s, %s, %s)", (bldg, room, reservation_date, period))
                print('Room available! Reservation booked.')

                print('Please provide your name.')
                name = input('Name: ')

                cur.execute("execute setUser (%s)", (name,))

                cur.execute("execute getId (%s)", (name,))
                id = cur.fetchone()

                cur.execute("execute UpdateReservationUser(%s, %s, %s, %s, %s)", (id, bldg, room, reservation_date, period))
                
                cur.execute("execute getCode(%s, %s, %s, %s)", (bldg, room, reservation_date, period))
                code = cur.fetchone()
                conn.commit()
                print('Reservation sucessfully updated!\n Your reservation code is: ' + str(code) + 
                      '\n Returning to main menu...')

# TODO: delete a reservation given its code

def delete_op(conn):
    if conn:
        with conn.cursor() as cur:
            print('Please provide provide the code on the reservation.')
            code = input('Code: ')
            if code is None:
                print('Please provide a reservation code.')
                conn.rollback()
            else:
                print('Searching...')

                cur.execute("execute QueryReservationExistsByCode(%s)", (code,))
                if cur.fetchone() is None:
                    print('Reservation not found.\nReturning to main menu...')
                    conn.rollback()
                else:
                    cur.execute("execute DeleteReservation(%s)", (code,))
                    print('Reservation Deleted.\n Returning to main menu...')



if __name__ == "__main__":
    with db_connect() as conn: 
        op = 0
        while op != 4: 
            menu()
            op = int(input('? '))
            if op == 1: 
                list_op(conn)
            elif op == 2:
                reserve_op(conn)
            elif op == 3:
                delete_op(conn)